import os
import sys
import requests
from openai import OpenAI

# Modify the SimpleAGI class to handle headless environments
class SimpleAGI:
    def __init__(self):
        # Set up API keys from environment variables
        self.groq_api_key = os.environ.get("GROQ_API_KEY", "")
        self.openai_api_key = os.environ.get("OPENAI_API_KEY", "")
        
        # Initialize OpenAI client if API key is available
        if self.openai_api_key:
            self.openai_client = OpenAI(api_key=self.openai_api_key)
        else:
            self.openai_client = None
        
        # Check if running in headless environment
        self.has_display = "DISPLAY" in os.environ
        
        # Initialize speech recognition and synthesis if available
        self.speech_recognition_available = False
        self.speech_synthesis_available = False
        
        try:
            import speech_recognition
            self.speech_recognition_available = True
        except ImportError:
            pass
        
        try:
            import pyttsx3
            self.speech_synthesis_available = True
            self.engine = pyttsx3.init()
        except ImportError:
            pass
        except Exception:
            # pyttsx3 might fail in headless environments
            pass
    
    def call_ollama(self, prompt):
        """Call Ollama local LLM."""
        try:
            # Assuming Ollama is running locally and has an API
            url = "http://localhost:11434/api/generate"
            payload = {
                "model": "llama2",
                "prompt": prompt,
                "stream": False
            }
            response = requests.post(url, json=payload)
            if response.status_code == 200:
                return response.json()["response"]
            else:
                return f"Error with Ollama: {response.text}"
        except Exception as e:
            return f"Error calling Ollama: {str(e)}"
    
    def call_groq(self, prompt):
        """Call Groq API."""
        if not self.groq_api_key:
            return "Groq API key not configured"
        
        try:
            url = "https://api.groq.com/openai/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {self.groq_api_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": "llama3-70b-8192",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7,
                "max_tokens": 2048
            }
            response = requests.post(url, json=payload, headers=headers)
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
            else:
                return f"Error with Groq: {response.status_code} - {response.text}"
        except Exception as e:
            return f"Error calling Groq: {str(e)}"
    
    def analyze_image(self, image_path):
        """Analyze image using OpenAI Vision API."""
        if not self.openai_client:
            return "OpenAI API key not configured"
        
        if not image_path or not os.path.exists(image_path):
            return "Image not found"
        
        try:
            with open(image_path, "rb") as image_file:
                base64_image = image_file.read()
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4-vision-preview",
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "Describe this image in detail"},
                            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
                        ]
                    }
                ],
                max_tokens=500
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"Error analyzing image: {str(e)}"
    
    def process_input(self, input_text, image_path=None):
        """Process user input and generate response."""
        response = ""
        
        # If there's an image, use OpenAI Vision API
        if image_path:
            image_description = self.analyze_image(image_path)
            response += f"Image analysis: {image_description}\n\n"
        
        # Use Groq if available, otherwise fall back to Ollama
        if self.groq_api_key:
            text_response = self.call_groq(input_text)
        else:
            text_response = self.call_ollama(input_text)
        
        response += f"{text_response}"
        
        # Speak the response if speech synthesis is available
        if self.speech_synthesis_available:
            try:
                self.engine.say(text_response)
                self.engine.runAndWait()
            except:
                pass
        
        return response
    
    def execute_command(self, command):
        """Execute a system command."""
        try:
            # Limit commands for security
            if any(unsafe_cmd in command.lower() for unsafe_cmd in ['rm -rf', 'sudo', 'chmod', 'chown']):
                return "Command not allowed for security reasons"
            
            import subprocess
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            return result.stdout + result.stderr
        except Exception as e:
            return f"Error executing command: {str(e)}"
    
    def capture_image(self):
        """Capture an image from the camera."""
        if not self.has_display:
            return "Camera not available in headless environment"
        
        try:
            import pyautogui
            import tempfile
            
            # Create a temporary file for the screenshot
            temp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            temp_file.close()
            
            # Take a screenshot
            pyautogui.screenshot(temp_file.name)
            
            return temp_file.name
        except Exception as e:
            return f"Error capturing image: {str(e)}"

# For testing
if __name__ == "__main__":
    agi = SimpleAGI()
    print(agi.process_input("Hello, how are you today?"))
