// Chat functionality for Simple AGI Web Interface

document.addEventListener('DOMContentLoaded', function() {
    // Socket.io connection
    const socket = io();
    
    // DOM Elements
    const messageForm = document.getElementById('message-form');
    const messageInput = document.getElementById('message-input');
    const chatMessages = document.getElementById('chat-messages');
    const voiceInputBtn = document.getElementById('voice-input-btn');
    const captureImageBtn = document.getElementById('capture-image-btn');
    const uploadFileBtn = document.getElementById('upload-file-btn');
    const executeCommandBtn = document.getElementById('execute-command-btn');
    const browseUrlBtn = document.getElementById('browse-url-btn');
    const clearChatBtn = document.getElementById('clear-chat-btn');
    
    // Modals
    const uploadModal = document.getElementById('upload-modal');
    const commandModal = document.getElementById('command-modal');
    const urlModal = document.getElementById('url-modal');
    const imageModal = document.getElementById('image-modal');
    const closeButtons = document.querySelectorAll('.close');
    
    // Forms
    const uploadForm = document.getElementById('upload-form');
    const commandForm = document.getElementById('command-form');
    const urlForm = document.getElementById('url-form');
    
    // Camera elements
    const cameraPreview = document.getElementById('camera-preview');
    const cameraCanvas = document.getElementById('camera-canvas');
    const captureBtn = document.getElementById('capture-btn');
    
    // Variables
    let currentImagePath = null;
    let mediaStream = null;
    
    // Connect to socket
    socket.on('connect', function() {
        console.log('Connected to server');
        addSystemMessage('Connected to AGI server');
    });
    
    socket.on('disconnect', function() {
        console.log('Disconnected from server');
        addSystemMessage('Disconnected from AGI server');
    });
    
    socket.on('status', function(data) {
        console.log('Status:', data);
        addSystemMessage(data.message);
    });
    
    socket.on('error', function(data) {
        console.error('Error:', data);
        addSystemMessage('Error: ' + data.message, 'error');
    });
    
    socket.on('response', function(data) {
        console.log('Response:', data);
        addAssistantMessage(data.message);
    });
    
    socket.on('command_result', function(data) {
        console.log('Command result:', data);
        addSystemMessage('Command result: ' + data.result);
    });
    
    socket.on('open_url', function(data) {
        console.log('Opening URL:', data);
        window.open(data.url, '_blank');
    });
    
    socket.on('request_image_upload', function() {
        console.log('Image upload requested');
        openModal(uploadModal);
    });
    
    // Event Listeners
    messageForm.addEventListener('submit', function(e) {
        e.preventDefault();
        sendMessage();
    });
    
    voiceInputBtn.addEventListener('click', function() {
        startVoiceInput();
    });
    
    captureImageBtn.addEventListener('click', function() {
        openModal(imageModal);
        startCamera();
    });
    
    uploadFileBtn.addEventListener('click', function() {
        openModal(uploadModal);
    });
    
    executeCommandBtn.addEventListener('click', function() {
        openModal(commandModal);
    });
    
    browseUrlBtn.addEventListener('click', function() {
        openModal(urlModal);
    });
    
    clearChatBtn.addEventListener('click', function() {
        clearChat();
    });
    
    closeButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            closeAllModals();
            stopCamera();
        });
    });
    
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        uploadFile();
    });
    
    commandForm.addEventListener('submit', function(e) {
        e.preventDefault();
        executeCommand();
    });
    
    urlForm.addEventListener('submit', function(e) {
        e.preventDefault();
        browseUrl();
    });
    
    captureBtn.addEventListener('click', function() {
        captureImage();
    });
    
    // Functions
    function sendMessage() {
        const message = messageInput.value.trim();
        if (!message) return;
        
        addUserMessage(message);
        
        // Send to server
        socket.emit('message', {
            message: message,
            image_path: currentImagePath
        });
        
        // Clear input and image path
        messageInput.value = '';
        currentImagePath = null;
    }
    
    function addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message user';
        
        const contentElement = document.createElement('div');
        contentElement.className = 'message-content';
        
        const textElement = document.createElement('p');
        textElement.textContent = message;
        
        const timeElement = document.createElement('div');
        timeElement.className = 'message-time';
        timeElement.textContent = getCurrentTime();
        
        contentElement.appendChild(textElement);
        contentElement.appendChild(timeElement);
        messageElement.appendChild(contentElement);
        
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    function addAssistantMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message assistant';
        
        const contentElement = document.createElement('div');
        contentElement.className = 'message-content';
        
        // Handle markdown-like formatting
        message = message.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        message = message.replace(/\*(.*?)\*/g, '<em>$1</em>');
        message = message.replace(/`(.*?)`/g, '<code>$1</code>');
        message = message.replace(/\n/g, '<br>');
        
        contentElement.innerHTML = `<p>${message}</p>`;
        
        const timeElement = document.createElement('div');
        timeElement.className = 'message-time';
        timeElement.textContent = getCurrentTime();
        
        contentElement.appendChild(timeElement);
        messageElement.appendChild(contentElement);
        
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    function addSystemMessage(message, type = 'info') {
        const messageElement = document.createElement('div');
        messageElement.className = 'message system';
        
        const contentElement = document.createElement('div');
        contentElement.className = 'message-content';
        
        if (type === 'error') {
            contentElement.style.backgroundColor = '#f8d7da';
            contentElement.style.color = '#721c24';
        }
        
        const textElement = document.createElement('p');
        textElement.textContent = message;
        
        contentElement.appendChild(textElement);
        messageElement.appendChild(contentElement);
        
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    function getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    function clearChat() {
        // Keep the first system message
        const firstMessage = chatMessages.querySelector('.message.system');
        chatMessages.innerHTML = '';
        if (firstMessage) {
            chatMessages.appendChild(firstMessage);
        }
    }
    
    function openModal(modal) {
        closeAllModals();
        modal.style.display = 'flex';
    }
    
    function closeAllModals() {
        const modals = [uploadModal, commandModal, urlModal, imageModal];
        modals.forEach(function(modal) {
            modal.style.display = 'none';
        });
    }
    
    function uploadFile() {
        const fileInput = document.getElementById('file-input');
        const file = fileInput.files[0];
        
        if (!file) {
            addSystemMessage('No file selected', 'error');
            return;
        }
        
        const formData = new FormData();
        formData.append('file', file);
        
        fetch('/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                addSystemMessage('Error uploading file: ' + data.error, 'error');
            } else {
                addSystemMessage('File uploaded: ' + data.filename);
                currentImagePath = data.filepath;
                closeAllModals();
                
                // Add a message about the uploaded file
                messageInput.value = `I've uploaded a file named ${data.filename}. Please analyze it.`;
                sendMessage();
            }
        })
        .catch(error => {
            addSystemMessage('Error uploading file: ' + error, 'error');
        });
    }
    
    function executeCommand() {
        const commandInput = document.getElementById('command-input');
        const command = commandInput.value.trim();
        
        if (!command) {
            addSystemMessage('No command entered', 'error');
            return;
        }
        
        socket.emit('execute_command', { command: command });
        
        addSystemMessage('Executing command: ' + command);
        commandInput.value = '';
        closeAllModals();
    }
    
    function browseUrl() {
        const urlInput = document.getElementById('url-input');
        const url = urlInput.value.trim();
        
        if (!url) {
            addSystemMessage('No URL entered', 'error');
            return;
        }
        
        socket.emit('browse_url', { url: url });
        
        addSystemMessage('Opening URL: ' + url);
        urlInput.value = '';
        closeAllModals();
    }
    
    function startCamera() {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(function(stream) {
                    mediaStream = stream;
                    cameraPreview.srcObject = stream;
                    cameraPreview.play();
                })
                .catch(function(error) {
                    addSystemMessage('Error accessing camera: ' + error, 'error');
                });
        } else {
            addSystemMessage('Camera not supported in this browser', 'error');
        }
    }
    
    function stopCamera() {
        if (mediaStream) {
            mediaStream.getTracks().forEach(track => track.stop());
            mediaStream = null;
        }
    }
    
    function captureImage() {
        if (!mediaStream) {
            addSystemMessage('Camera not started', 'error');
            return;
        }
        
        const context = cameraCanvas.getContext('2d');
        cameraCanvas.width = cameraPreview.videoWidth;
        cameraCanvas.height = cameraPreview.videoHeight;
        context.drawImage(cameraPreview, 0, 0, cameraCanvas.width, cameraCanvas.height);
        
        // Convert to blob
        cameraCanvas.toBlob(function(blob) {
            const file = new File([blob], 'capture.jpg', { type: 'image/jpeg' });
            
            const formData = new FormData();
            formData.append('file', file);
            
            fetch('/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    addSystemMessage('Error uploading image: ' + data.error, 'error');
                } else {
                    addSystemMessage('Image captured and uploaded');
                    currentImagePath = data.filepath;
                    closeAllModals();
                    stopCamera();
                    
                    // Add a message about the captured image
                    messageInput.value = 'I've captured an image. Please analyze it.';
                    sendMessage();
                }
            })
            .catch(error => {
                addSystemMessage('Error uploading image: ' + error, 'error');
            });
        }, 'image/jpeg', 0.8);
    }
    
    function startVoiceInput() {
        if (!('webkitSpeechRecognition' in window)) {
            addSystemMessage('Speech recognition not supported in this browser', 'error');
            return;
        }
        
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        
        recognition.onstart = function() {
            voiceInputBtn.classList.add('active');
            addSystemMessage('Listening...');
        };
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            messageInput.value = transcript;
            addSystemMessage('You said: ' + transcript);
        };
        
        recognition.onerror = function(event) {
            addSystemMessage('Error in speech recognition: ' + event.error, 'error');
        };
        
        recognition.onend = function() {
            voiceInputBtn.classList.remove('active');
        };
        
        recognition.start();
    }
});
