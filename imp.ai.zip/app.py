#!/usr/bin/env python3
"""
Web Interface for Simple AGI
A Flask-based web interface for the Simple AGI system.
"""

import os
import sys
import json
import time
import uuid
import base64
import tempfile
import threading
import subprocess
from pathlib import Path
from functools import wraps

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, send_from_directory
from flask_socketio import SocketIO, emit

# Import SimpleAGI directly from current directory
try:
    from simple_agi_implementation import SimpleAGI
except ImportError:
    print("Error: simple_agi_implementation.py not found in current directory.")
    sys.exit(1)

# Configuration
CONFIG_DIR = Path.home() / ".simple_agi"
CONFIG_FILE = CONFIG_DIR / "config.json"
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(24))
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
socketio = SocketIO(app)

# Store AGI instances for each session
agi_instances = {}

# Authentication (simple for demo purposes)
USERS = {
    'lostsoal24@gmail.com': '238232dD.'  # Change this in production
}

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in USERS and USERS[username] == password:
            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('index'))
        else:
            error = 'Invalid credentials. Please try again.'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/settings')
@login_required
def settings():
    # Load configuration
    config = {}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
    
    # Mask API keys
    if 'api_keys' in config:
        for key in config['api_keys']:
            if config['api_keys'][key]:
                config['api_keys'][key] = '********'
    
    return render_template('settings.html', config=config)

@app.route('/save_settings', methods=['POST'])
@login_required
def save_settings():
    # Load existing configuration
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
    else:
        # Create default config
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
        config = {
            "api_keys": {
                "openai": "",
                "groq": os.environ.get("GROQ_API_KEY", ""),
                "anthropic": "",
                "google": ""
            },
            "models": {
                "default_chat": "groq:llama3-70b-8192",
                "default_vision": "openai:gpt-4-vision-preview",
                "default_voice": "system"
            },
            "ollama": {
                "host": "http://localhost:11434"
            },
            "voice": {
                "enabled": True,
                "rate": 150,
                "volume": 1.0
            },
            "system_prompt": "You are a helpful AI assistant that can control the computer, browse the web, and assist with various tasks."
        }
    
    # Update API keys
    for key in config['api_keys']:
        if key in request.form and request.form[key]:
            if request.form[key] != '********':  # Only update if changed
                config['api_keys'][key] = request.form[key]
    
    # Update models
    for model_type in config['models']:
        form_key = f"model_{model_type}"
        if form_key in request.form:
            config['models'][model_type] = request.form[form_key]
    
    # Update Ollama settings
    if 'ollama_host' in request.form:
        config['ollama']['host'] = request.form['ollama_host']
    
    # Update voice settings
    config['voice']['enabled'] = 'voice_enabled' in request.form
    if 'voice_rate' in request.form:
        try:
            config['voice']['rate'] = int(request.form['voice_rate'])
        except ValueError:
            pass
    if 'voice_volume' in request.form:
        try:
            config['voice']['volume'] = float(request.form['voice_volume'])
        except ValueError:
            pass
    
    # Update system prompt
    if 'system_prompt' in request.form:
        config['system_prompt'] = request.form['system_prompt']
    
    # Save configuration
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)
    
    return redirect(url_for('settings'))

@app.route('/upload', methods=['POST'])
@login_required
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if file:
        filename = str(uuid.uuid4()) + os.path.splitext(file.filename)[1]
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        return jsonify({'success': True, 'filepath': filepath, 'filename': file.filename})

@app.route('/uploads/<filename>')
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@socketio.on('connect')
def handle_connect():
    if 'logged_in' not in session:
        return False
    
    # Create a new AGI instance for this session if it doesn't exist
    if session.sid not in agi_instances:
        agi_instances[session.sid] = SimpleAGI()
        emit('status', {'message': 'Connected to AGI'})

@socketio.on('disconnect')
def handle_disconnect():
    # Clean up AGI instance when user disconnects
    if session.sid in agi_instances:
        del agi_instances[session.sid]

@socketio.on('message')
def handle_message(data):
    if session.sid not in agi_instances:
        emit('error', {'message': 'AGI not initialized'})
        return
    
    user_input = data.get('message', '')
    image_path = data.get('image_path', None)
    
    # Process in a separate thread to avoid blocking
    def process_message():
        try:
            agi = agi_instances[session.sid]
            response = agi.process_input(user_input, image_path)
            emit('response', {'message': response})
        except Exception as e:
            emit('error', {'message': f"Error processing message: {str(e)}"})
    
    threading.Thread(target=process_message).start()

@socketio.on('capture_image')
def handle_capture_image():
    if session.sid not in agi_instances:
        emit('error', {'message': 'AGI not initialized'})
        return
    
    # For web interface, we can't capture directly, so we'll use the uploaded image
    emit('request_image_upload')

@socketio.on('execute_command')
def handle_execute_command(data):
    if session.sid not in agi_instances:
        emit('error', {'message': 'AGI not initialized'})
        return
    
    command = data.get('command', '')
    
    # For security reasons, limit commands in web interface
    if any(unsafe_cmd in command.lower() for unsafe_cmd in ['rm', 'sudo', 'chmod', 'chown']):
        emit('error', {'message': 'Command not allowed for security reasons'})
        return
    
    try:
        agi = agi_instances[session.sid]
        result = agi.execute_command(command)
        emit('command_result', {'result': result})
    except Exception as e:
        emit('error', {'message': f"Error executing command: {str(e)}"})

@socketio.on('browse_url')
def handle_browse_url(data):
    if session.sid not in agi_instances:
        emit('error', {'message': 'AGI not initialized'})
        return
    
    url = data.get('url', '')
    
    # For web interface, we can't open browser directly
    emit('open_url', {'url': url})

if __name__ == '__main__':
    # Check if running in production or development
    if os.environ.get('FLASK_ENV') == 'production':
        # In production, use gunicorn or similar
        print("Running in production mode")
        # This will be handled by gunicorn
    else:
        # In development, use Flask's built-in server
        print("Running in development mode")
        socketio.run(app, debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 8000)))
